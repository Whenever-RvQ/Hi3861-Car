
/**
 * 
 * car_motor.c： 电机驱动板 控制 程序
 * 
 * PWM频率 = Fcs时钟频率 / Freq分频倍数 
 * 
 * CPU = 160MHZ  Freq = 4000;
 * 
 * PWM = ( 160 * 1000 * 1000 Hz ) / ( 4 * 1000 ) = 40 * 1000 Hz = 40 KHz
 * 
 * 
 * 这个取值主要看硬件响应范围，例如 无源蜂鸣器频率是1900-4000HZ 
 * 
 * Freq 是 unsigned short 类型 无符号短整形 范围在 0-65535 65.535 * 1000
 * 
 * PWM = ( 160 * 1000 * 1000 Hz ) / ( 40 * 1000 ) = 4 * 1000 Hz = 4 KHz
 * 
 * 
 *  注意: 开启PWM功能
 *  vendor\hisi\hi3861\hi3861\build\config\usr_config.mk
 *  # CONFIG_PWM_SUPPORT is not set 修改为 CONFIG_PWM_SUPPORT=y
 * 
 **/ 

#include "car_motor.h"

unsigned short frequency = 4000;
unsigned short velocity = 3000;

// 端口 初始化
void Motor_Init(void)
{    
    // motor-a

    // in1 GPIO1 OUT PWM4
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_1, WIFI_IOT_GPIO_DIR_OUT);
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_1, WIFI_IOT_IO_FUNC_GPIO_1_PWM4_OUT);       

    // in2 GPIO2 OUT PWM2
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_2, WIFI_IOT_GPIO_DIR_OUT);
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_2, WIFI_IOT_IO_FUNC_GPIO_2_PWM2_OUT);      

    // motor-b

    // in3 GPIO6 OUT PWM3
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_6, WIFI_IOT_GPIO_DIR_OUT);
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_6, WIFI_IOT_IO_FUNC_GPIO_6_PWM3_OUT);      

    // in4 GPIO8 OUT PWM1
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_8, WIFI_IOT_GPIO_DIR_OUT);
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_8, WIFI_IOT_IO_FUNC_GPIO_8_PWM1_OUT);  

    // PWM 初始化
    PwmInit(WIFI_IOT_PWM_PORT_PWM4);
    PwmInit(WIFI_IOT_PWM_PORT_PWM2);

    PwmInit(WIFI_IOT_PWM_PORT_PWM3);
    PwmInit(WIFI_IOT_PWM_PORT_PWM1);
}

// 运行
static void Motor_Run(unsigned short in1_duty, unsigned short in2_duty, unsigned short in3_duty, unsigned short in4_duty)
{
    // 停止
    PwmStop(WIFI_IOT_PWM_PORT_PWM4);
    PwmStop(WIFI_IOT_PWM_PORT_PWM2);

    PwmStop(WIFI_IOT_PWM_PORT_PWM3);
    PwmStop(WIFI_IOT_PWM_PORT_PWM1);

    // unsigned int PwmStart(WifiIotPwmPort port, unsigned short duty, unsigned short freq);

    // 启动
    PwmStart(WIFI_IOT_PWM_PORT_PWM4, in1_duty, frequency);
    PwmStart(WIFI_IOT_PWM_PORT_PWM2, in2_duty, frequency);

    PwmStart(WIFI_IOT_PWM_PORT_PWM3, in3_duty, frequency);
    PwmStart(WIFI_IOT_PWM_PORT_PWM1, in4_duty, frequency);
}

// 关闭 PWM
void Motor_Quit(void)
{

    // 停止 PWM
    PwmStop(WIFI_IOT_PWM_PORT_PWM4);
    PwmStop(WIFI_IOT_PWM_PORT_PWM2);

    PwmStop(WIFI_IOT_PWM_PORT_PWM3);
    PwmStop(WIFI_IOT_PWM_PORT_PWM1);

    // 关闭 PWM
    PwmDeinit(WIFI_IOT_PWM_PORT_PWM4);
    PwmDeinit(WIFI_IOT_PWM_PORT_PWM2);

    PwmDeinit(WIFI_IOT_PWM_PORT_PWM3);
    PwmDeinit(WIFI_IOT_PWM_PORT_PWM1);

}

// 前进
void Motor_Forward(void)
{    
    Motor_Run(velocity, 0, velocity, 0);
}

// 后退
void Motor_Backward(void)
{
    Motor_Run(0, velocity, 0, velocity);
}

// 原地 左转
void Motor_Left(void)
{
    Motor_Run(0, velocity, velocity, 0);
}

// 原地 右转
void Motor_Right(void)
{
    Motor_Run(velocity, 0, 0, velocity);
}

// 刹车 制动抱死
void Motor_Stop(void)
{
    Motor_Run(frequency, frequency, frequency, frequency);
}

// 等待 空档
void Motor_Wait(void)
{
    Motor_Run(0, 0, 0, 0);
}

// 设置速度
void Motor_Set_Velocity(unsigned short v)
{
    velocity = v;
} 

// 返回当前速度
unsigned short Motor_Get_Velocity(void)
{
    return velocity;
}

