

/**
 * 
 * 
 * switch 按键  GPIO05  ADC2
 * 
 * beep   蜂鸣器 GPIO09 PWM0
 * 
 * lamp   小灯  GPIO09 
 * 
 * 
 **/

#include "car_module.h"


// 初始化
void Module_Init(void)
{

    // 1 端口设置 普通输入输出 端口 
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_5, WIFI_IOT_IO_FUNC_GPIO_5_GPIO);
    // 2 端口属性 设置输入端口
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_5, WIFI_IOT_GPIO_DIR_IN);
    // 3 端口状态 设置无拉力状态
    IoSetPull(WIFI_IOT_IO_NAME_GPIO_5, WIFI_IOT_IO_PULL_NONE);

    //设置端口功能 
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_9, WIFI_IOT_IO_FUNC_GPIO_9_PWM0_OUT);   //蜂鸣器 脉冲模式
    //设置端口属性    
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_9, WIFI_IOT_GPIO_DIR_OUT);             //蜂鸣器为输出模式
    //设置端口状态    
    PwmInit(WIFI_IOT_PWM_PORT_PWM0);                                        //蜂鸣器PWM初始化

}

// S1 S2 按键 返回值
int Module_Switch(void)
{

    int switch_x = 0;   // 按键;

    // ADC通道 GPIO5 对应 ADC2
    WifiIotAdcChannelIndex channel = WIFI_IOT_ADC_CHANNEL_2;
    // 返回值
    unsigned short data = 0;
    // 模数转换模式 就是一种采样算法 最高精度采样 
    WifiIotAdcEquModelSel equModel = WIFI_IOT_ADC_EQU_MODEL_8;
    // 控制方式 默认 自动
    WifiIotAdcCurBais curBais = WIFI_IOT_ADC_CUR_BAIS_DEFAULT;
    // 指示从重置到转换开始的时间计数。一个计数等于334纳秒。该值必须介于0到0xFF0之间。 很多人不加时间间隔 但是好像 加点可以消抖
    unsigned short rstCnt = 10;

    if(AdcRead(channel, &data, equModel, curBais, rstCnt) == WIFI_IOT_SUCCESS)
    {       

        if( (data >= 229 ) && (data <= 512) )
        {
            printf(" [AdcRead] ADC : %d \n", data);
            switch_x = 1;
        }

        if( (data >= 513 ) && (data <= 858) )
        {
            printf(" [AdcRead] ADC : %d \n", data);
            switch_x = 2;
        }
    }

    return switch_x;

}

// 蜂鸣器 f频率 响n秒
void Module_Beep(unsigned short f, int n)
{

    // 无符号短整形：unsigned short 取值范围：0~65535 CPU频率：160MHz = 160 * 1000 * 1000
    PwmStart(WIFI_IOT_PWM_PORT_PWM0, f, 40*1000);     // 4K

    sleep(n);    // 响n秒

    PwmStop(WIFI_IOT_PWM_PORT_PWM0); //停止PWM

}


