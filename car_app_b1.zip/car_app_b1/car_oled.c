
/**
 * 
 * car_oled.c
 * 
 * OLED显示屏 
 * 
 **/ 


#include "car_oled.h"
#include "oled_fonts.h"


#define W_CMD 0x00   // 写入指令地址
#define W_DAT 0x40   // 写入数据地址

static char oled_buff[8][128];    // 全屏显示缓存

// cont：指令或数据 ， byte：1个字节的数据 
static void OLED_I2C_Write(unsigned char cont, unsigned char byte)
{

    unsigned int i2c_state = 0; // 执行返回状态

    // 参数部分
    WifiIotI2cIdx i2c_id = WIFI_IOT_I2C_IDX_0;  // I2C通道
    unsigned short device_addr = 0x78;          // 设备地址
    WifiIotI2cData i2c_data = {0};              // 通信数据

    unsigned char send_buf[] = {cont, byte};    // 写入两条 cont 输入要写入 指令 还是 数据 的 寄存器地址 ， byte 要写入的 数据
    unsigned int  send_len = 2;

    i2c_data.sendBuf = send_buf;
    i2c_data.sendLen = send_len;

    // 写入数据
    i2c_state = I2cWrite(i2c_id, device_addr, &i2c_data);
    
    // 测试 打印 错误 状态 信息
    if(i2c_state != WIFI_IOT_SUCCESS)
    {
        printf(" [OLED_I2C_Write] Error! cont = 0x%x ， byte = 0x%x ， state = %d \n", cont, byte, i2c_state);    // 查验 写入那条数据 出了 什么错
    }

}

// OLED 设备 设置 初始化 采用的是手册标准流程
void OLED_Init(void)
{
    // 关闭显示

    OLED_I2C_Write(W_CMD, 0xAE);

    // 设置显示时钟分频比/振荡器频率

    OLED_I2C_Write(W_CMD, 0xD5);
    OLED_I2C_Write(W_CMD, 0x80);

    // 设置复用比

    OLED_I2C_Write(W_CMD, 0xA8);
    OLED_I2C_Write(W_CMD, 0x3F);

    // 设置显示偏移

    OLED_I2C_Write(W_CMD, 0xD3);
    OLED_I2C_Write(W_CMD, 0x00);
    
    // 设置显示起始行

    OLED_I2C_Write(W_CMD, 0x40);

    // 设置段重映射

    OLED_I2C_Write(W_CMD, 0xA1);

    // 设置COM输出扫描方向

    OLED_I2C_Write(W_CMD, 0xC8);

    // 设置COM引脚硬件配置

    OLED_I2C_Write(W_CMD, 0xDA);
    OLED_I2C_Write(W_CMD, 0x12);

    // 设置对比度控制

    OLED_I2C_Write(W_CMD, 0x81);
    OLED_I2C_Write(W_CMD, 0x66);
    
    // 设置预充电时间
    
    OLED_I2C_Write(W_CMD, 0xD9);
    OLED_I2C_Write(W_CMD, 0x22);

    // 设置VCOMH取消选择级别

    OLED_I2C_Write(W_CMD, 0xDB);
    OLED_I2C_Write(W_CMD, 0x30);

    // 打开/关闭整个显示器

    OLED_I2C_Write(W_CMD, 0xA4);

    // 设置正常/反向显示

    OLED_I2C_Write(W_CMD, 0xA6);

    // 设置充电泵

    OLED_I2C_Write(W_CMD, 0x8D);
    OLED_I2C_Write(W_CMD, 0x14);

    // 设置显示方式

    OLED_I2C_Write(W_CMD, 0x20);  // 内存地址
    OLED_I2C_Write(W_CMD, 0x00);  // 水平方向

    // 打开显示

    OLED_I2C_Write(W_CMD, 0xAF);

}

// OLED 显示信息 
// 因为设置水平显示， 所以1个字都不能少 
void OLED_Show(void)
{
    int i, j;

    for(i=0; i<8; i++)
    {
        for(j=0; j<128; j++)
        {
            OLED_I2C_Write(W_DAT, oled_buff[i][j]); // 把缓存数据写入到OLED
        }
    }
}

// 清空 OLED 缓存 注意：并不能清空屏幕
void OLED_Clear(void)
{
    int i, j;

    for(i=0; i<8; i++)
    {
        for(j=0; j<128; j++)
        {
            oled_buff[i][j] = 0x00;
        }
    }
}

// 必须是英数输入的字符 
// 只输入一行字符， 没做换行处理，也没做溢出检测， x + ( 字符长度 * 8 ) < 128
// y < ( 8 - 1 )， 1个字符占2行，最多显示4行字符
void OLED_String(int x, int y, char* str)
{
    int i, j = strlen(str);    // i 字符数组的字符序号  j字符数组长度

    //printf(" %s = %d \n", str, j);

    // 加了一条测试用报错信息
    if((j*8 + x) > 128 )
    {
        printf(" Error! Too long \n");
    }

    // 逐字输入到缓存
    for(i=0; i<j; i++)
    {

        int l = x + i*8;        // 将字符坐标 转换成 显示缓存的 坐标
        int c = str[i] - 32;    // 将字符内容 转换成 字符数组的 坐标

        //printf(" %d : %c = %d \n", i, str[i], c);

        // 把显示字库信息 倒入到显示缓存数组 可以做个循环 这么看更直观

        // 1个字符 分上下2部分 宽占8个长度 整体占8*16个像素

        oled_buff[y][l+0] = fonts[c][0];
        oled_buff[y][l+1] = fonts[c][1];
        oled_buff[y][l+2] = fonts[c][2];
        oled_buff[y][l+3] = fonts[c][3];
        oled_buff[y][l+4] = fonts[c][4];
        oled_buff[y][l+5] = fonts[c][5];
        oled_buff[y][l+6] = fonts[c][6];
        oled_buff[y][l+7] = fonts[c][7];

        oled_buff[y+1][l+0] = fonts[c][8];
        oled_buff[y+1][l+1] = fonts[c][9];
        oled_buff[y+1][l+2] = fonts[c][10];
        oled_buff[y+1][l+3] = fonts[c][11];
        oled_buff[y+1][l+4] = fonts[c][12];
        oled_buff[y+1][l+5] = fonts[c][13];
        oled_buff[y+1][l+6] = fonts[c][14];
        oled_buff[y+1][l+7] = fonts[c][15];

    }

}