
#ifndef __CAR_HCSR04_H__
#define __CAR_HCSR04_H__


#include <unistd.h>
#include <sys/time.h>

#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"


// 超声波 端口 初始化
void Hcsr04_Init(void);

// 测量距离 返回值 毫米
int Hcsr04_Measure(void);

#endif