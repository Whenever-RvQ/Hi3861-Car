
/**
 * 
 * car_hcsr04.c
 * 
 * HC-SR04 超声波 测距模块
 * 
 * 
 * Trig GPIO12  控制端 
 * Echo GPIO07  接收端
 * 
 **/ 

#include "car_hcsr04.h"

// 超声波 端口 初始化
void Hcsr04_Init(void)
{

    // Trig 输出 gpio 12
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_FUNC_GPIO_12_GPIO); // 普通输入输出端口
    GpioSetDir(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_GPIO_DIR_OUT);            // 输出模式
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_GPIO_VALUE0);       // 初始 低电平

    // Echo 接收 gpio 7
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_7, WIFI_IOT_IO_FUNC_GPIO_7_GPIO);   // 普通输入输出端口
    GpioSetDir(WIFI_IOT_GPIO_IDX_7, WIFI_IOT_GPIO_DIR_IN);              // 输入模式
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_7, WIFI_IOT_GPIO_VALUE0);        // 初始 低电平

}

// 读取 系统时间 微秒
static time_t sys_time_us(void) {
    struct timeval current_time;
    gettimeofday(&current_time, NULL);
    time_t time_us = current_time.tv_sec * 1000000 + current_time.tv_usec;
    return time_us;
}

// 测量 距离
int Hcsr04_Measure(void)
{
    time_t start_time = 0;  // 开始时间
    time_t end_time = 0;    // 结束时间
    int distance = 0;     // 距离

    WifiIotGpioValue gpio_value = WIFI_IOT_GPIO_VALUE0; // 端口状态

    // 10us以上高电平  启动测量
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_GPIO_VALUE1);
    usleep(15);
    GpioSetOutputVal(WIFI_IOT_GPIO_IDX_12, WIFI_IOT_GPIO_VALUE0);

    // 检测 GPIO7 状态  如果是低电平 一直等待
    while(gpio_value == WIFI_IOT_GPIO_VALUE0)
    {
        GpioGetInputVal(WIFI_IOT_GPIO_IDX_7, &gpio_value);  // 返回GPIO7的端口状态            
    }
    // 如果不是低电平了 开始计时
    start_time = sys_time_us(); // 调取系统时间 

    // 如果不是高电平了 接收 结束
    while(gpio_value == WIFI_IOT_GPIO_VALUE1)
    {
        GpioGetInputVal(WIFI_IOT_GPIO_IDX_7, &gpio_value);            
    }
    // 记录结束后的系统时间
    end_time = sys_time_us();   // 结束时间

    // 计算距离
    distance = ( end_time - start_time ) * 340 / 1000 / 2;    // 距离 毫米  

    return distance;
}