

#ifndef __CAR_OLED_H__
#define __CAR_OLED_H__


//C库
#include <stdio.h>
#include <unistd.h>
#include <string.h>

//端口
#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"

//通信
#include "wifiiot_i2c.h"
#include "wifiiot_errno.h"

// OLED 设备 初始化
void OLED_Init(void);


// OLED 显示 缓存 信息
void OLED_Show(void);


// 清空 OLED 缓存
void OLED_Clear(void);


// 必须是英数输入的字符 
// 只输入一行字符， 没做折行处理，  1行16个字符, x + ( 字符长度 * 8 ) < 128 ，
// y < ( 8 - 1 ) 最多只满足 显示4行
void OLED_String(int x, int y, char* str);



#endif