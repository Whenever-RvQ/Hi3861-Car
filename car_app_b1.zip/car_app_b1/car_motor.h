

#ifndef __CAR_MOTOR_H__
#define __CAR_MOTOR_H__


#include <unistd.h>

#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"

#include "wifiiot_pwm.h"

// 端口 初始化
void Motor_Init(void);

// 前进
void Motor_Forward(void);

// 后退
void Motor_Backward(void);

// 左转
void Motor_Left(void);

// 右转
void Motor_Right(void);

// 刹车 制动抱死
void Motor_Stop(void);

// 等待 空档
void Motor_Wait(void);

// 设置速度
void Motor_Set_Velocity(unsigned short v);

// 返回当前速度
unsigned short Motor_Get_Velocity(void);

// 关闭 PWM
void Motor_Quit(void);


#endif