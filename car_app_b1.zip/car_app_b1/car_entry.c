
/**
 * 
 * car_entry.c
 * 
 * 完成到接入系统 和 主控制 
 * 
 * 
 **/ 

// c库
#include <stdio.h>
#include <unistd.h>
#include <string.h>

// 系统
#include "ohos_init.h"
#include "cmsis_os2.h"

#include <sys/time.h>

// 端口
#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"

#include "wifiiot_pwm.h"
#include "wifiiot_i2c.h"

#include "wifiiot_errno.h"

// 外设
#include "car_oled.h"   // 显示屏
#include "car_hcsr04.h" // 超声波
#include "car_motor.h"  // 电机驱动
#include "car_module.h" // 按键 蜂鸣


// 设备 集中 初始化
static void Car_Init(void)
{

    GpioInit(); //端口初始化

    Hcsr04_Init();  // 超声波端口初始化
    Motor_Init();   // 电机驱动控制端口初始化
    Module_Init();  // 小组件初始化 按键S1、S2 蜂鸣器

    // I2C 端口初始化 : gpio13 = SDA , gpio14 = SCL 
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_13, WIFI_IOT_IO_FUNC_GPIO_13_I2C0_SDA);
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_14, WIFI_IOT_IO_FUNC_GPIO_14_I2C0_SCL);

    // I2C 通信协议 初始化 参数
    WifiIotI2cIdx i2c_idx = WIFI_IOT_I2C_IDX_0; // 选择 I2C 通道 1 = WIFI_IOT_I2C_IDX_0 , 2 = WIFI_IOT_I2C_IDX_1 
    unsigned int baudrate = 400*1000;           // I2C 波特率 400k  标准 100Kbit/s ， 快速 400Kbit/s 主要看模块支持多大的 一般都支持400K

    // I2C 通信协议
    if(I2cInit(i2c_idx, baudrate) == WIFI_IOT_SUCCESS)   // wifiiot_errno.h 定义 #define WIFI_IOT_SUCCESS    0 ， #define WIFI_IOT_FAILURE   (-1) 成功返回 0 错误返回 -1
    {
        printf("I2C Init OK !!! \n");
    }
    else
    {
        printf("I2C Init NO !!! \n");
    }

    // 打印状态信息 也就测试时候用 或者 运行时做个返回判断

    // OLED 运行前的的 参数配置
    OLED_Init();

}

// S1\S2 蜂鸣 按键测试
void Module_Test(void)
{

    while(1)
    {
        int s = Module_Switch();

        if( s > 0)
        {
            if(s == 1)
            {
                Module_Beep(10*1000, 2);    // 10000 响2秒
            }

            if(s == 2)
            {
                Module_Beep(30*1000, 1);    // 30000 响1秒
            }
        }

    }

}


// 电机驱动控制 测试
void Motor_Test(void)
{

    Motor_Wait();   // 空档准备

    Motor_Set_Velocity(3200);

    Motor_Forward();    // 前进
    sleep(5);

    Motor_Stop();   // 停止
    sleep(2);

    Motor_Backward();    // 后退
    sleep(5);

    Motor_Stop();   // 停止
    sleep(2);

    Motor_Left();    // 左转
    sleep(5);

    Motor_Stop();   // 停止
    sleep(2);

    Motor_Right();    // 右转
    sleep(5);

    Motor_Stop();   // 停止
    sleep(2);

    int v = Motor_Get_Velocity();

    printf(" V: %d \n", v);

    Motor_Quit();   // 退出

}

// 屏幕 显示 测距结果
void HCSR04_Test(void)
{

    int i = 0;

    while( i < 100 )    // 连续测100次
    {

        int d = Hcsr04_Measure();   // 测量距离

        OLED_Clear();   // 清空缓存

        // 显示结果

        OLED_String(0, 0, "D:");

        // 将结果 转成字符串 屏幕显示

        char d_str[10];
        
        // 把int参数 转换成 char数组
        sprintf(d_str, "%d", d);

        OLED_String(16, 0, d_str);

        OLED_Show();

        i++;

        usleep(200 * 1000); // 空闲 200 毫秒
        
    }

}

// 屏幕 显示 测试
void OLED_Test(void)
{

    OLED_Clear();   // 清空缓存
    OLED_Show();    // 显示黑屏

    sleep(2); // 停2秒

    // 显示字符串

    OLED_String(0, 0, "hello!");
    OLED_Show();

    sleep(2); // 停2秒

    // 将整形 转成字符串 屏幕显示

    char int_str[10];
        
    // 把int参数 转换成 char数组
    sprintf(int_str, "%d", 123456);

    OLED_String(0, 2, int_str);
    OLED_Show();

    sleep(5); // 停5秒

    OLED_Clear();   // 清空缓存
    OLED_Show();    // 显示黑屏

}

void Car_Run_Test(void)
{

    // 空档 待机
    Motor_Wait();

    // 设置速度
    Motor_Set_Velocity(3000);

    while(1)
    {
        int d = Hcsr04_Measure();

        if(d > 200)
        {
            // 距离大于200毫米 前进
            Motor_Forward();
        }
        else
        {
            // 如果小于200毫米 停止
            Motor_Stop();
            // 向左转动一个角度 然后停止
            Motor_Left();
            usleep(200 * 1000);
            Motor_Stop();
        }

    }

}


static void *CarTask(const char *arg)
{
    (void)arg;

    // 设备 集中 初始化
    Car_Init();

    // 屏幕 显示 测试
    //OLED_Test();

    // 显示 测距 结果
    //HCSR04_Test();

    // 电机驱动控制 测试
    //Motor_Test();

    // 按键 蜂鸣 测试
    Module_Test();
    
    return NULL;
}

static void CarEntry(void)
{
    osThreadAttr_t attr;

    attr.name = "CarTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 1024;
    attr.priority = 25;

    if(osThreadNew((osThreadFunc_t)CarTask, NULL, &attr) == NULL)
    {
        printf(" [CarEntry] Falied to create CarTask! \n");
    }    
}

SYS_RUN(CarEntry);