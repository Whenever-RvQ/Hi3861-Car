

#ifndef __CAR_MODULE_H__
#define __CAR_MODULE_H__

#include <stdio.h>
#include <unistd.h>

#include "wifiiot_gpio.h"
#include "wifiiot_gpio_ex.h"

#include "wifiiot_pwm.h"
#include "wifiiot_adc.h"

#include "wifiiot_errno.h"

// 初始化
void Module_Init(void);

// S1 S2 按键 返回值
int Module_Switch(void);

// 蜂鸣器 f频率 响n秒
void Module_Beep(unsigned short f, int n);

#endif